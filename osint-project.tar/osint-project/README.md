# 🛰️ OSINT Monitor — מדריך התקנה

## מה בפנים?

```
osint-project/
├── server.js          ← השרת — אוסף נתונים ממקורות אמיתיים
├── package.json       ← רשימת חבילות
├── public/
│   └── index.html     ← הממשק (מובייל + דסקטופ)
└── README.md          ← המדריך הזה
```

## מקורות נתונים (אמיתיים!)

| מקור | סוג | תדירות סריקה |
|------|------|-------------|
| Jerusalem Post | RSS | כל 5 דקות |
| Al Jazeera | RSS | כל 5 דקות |
| BBC Middle East | RSS | כל 5 דקות |
| NYT Middle East | RSS | כל 5 דקות |
| Times of Israel | RSS | כל 5 דקות |
| GDELT | API | כל 3 דקות |
| פיקוד העורף | API | כל 15 שניות |

---

## 🚀 אפשרות 1: Railway (הכי קל — מומלץ!)

Railway הוא שירות אירוח חינמי שמריץ את הפרויקט בלחיצת כפתור.

### שלב 1: צור חשבון
1. לך ל-[railway.app](https://railway.app)
2. הירשם עם חשבון GitHub

### שלב 2: העלה ל-GitHub
1. צור חשבון ב-[github.com](https://github.com) (אם אין לך)
2. לחץ על ה-"+" בפינה הימנית → "New repository"
3. קרא לו `osint-monitor`
4. העלה את כל הקבצים מהתיקייה הזו (גרור ושחרר)

### שלב 3: הפעל ב-Railway
1. ב-Railway, לחץ "New Project"
2. בחר "Deploy from GitHub repo"
3. בחר את `osint-monitor`
4. Railway יזהה אוטומטית שזה Node.js ויריץ `npm start`
5. לחץ "Generate Domain" כדי לקבל כתובת אינטרנט

✅ **זהו! תוך 2-3 דקות האתר חי.**

---

## 💻 אפשרות 2: הרצה מקומית

### דרישות
- [Node.js](https://nodejs.org) (גרסה 18 ומעלה)

### שלבים
```bash
# 1. כנס לתיקייה
cd osint-project

# 2. התקן חבילות
npm install

# 3. הפעל
npm start
```

פתח בדפדפן: **http://localhost:3000**

---

## 🤖 הפעלת אנליסט AI

כדי שהניתוח AI יעבוד, צריך שלממשק תהיה גישה ל-Anthropic API.
הניתוח רץ ישירות מהדפדפן (כמו ב-Artifact של Claude).

**אם אתה מריץ את זה מחוץ ל-Claude:**
תצטרך להוסיף API key. פתח את `public/index.html`,
חפש את `fetch('https://api.anthropic.com/v1/messages'`
והוסף header:
```
'x-api-key': 'YOUR_API_KEY_HERE'
```

---

## 📱 שימוש

- **המפה** מראה אירועים בזמן אמת — נקודות עם פולס = אירועים טריים
- **צ'יפים** בתחתית המפה — סינון לפי סוג אירוע
- **טאב פיד** — רשימת כל האירועים, לחיצה פותחת פרטים
- **טאב איום** — הערכת איום לכל מדינה עם סיגמואיד + time-decay
- **טאב AI** — ניתוח מודיעיני, דו"ח מצב, תחזית

---

## ⚠️ הערות חשובות

- הנתונים הם ממקורות פתוחים בלבד (OSINT)
- האתר לא לקבלת החלטות — למידע בלבד
- פיקוד העורף עלול לחסום בקשות מחו"ל
- GDELT API חינמי אבל מוגבל בקצב
- RSS feeds יכולים להשתנות — אם פיד נשבר, עדכן את ה-URL ב-server.js
